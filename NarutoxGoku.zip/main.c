#include <gsKit.h>
#include <dmaKit.h>
#include <loadfile.h>
#include <debug.h>
#include <draw.h>
#include <pad.h>

#define SPEED 4

int main(void)
{
    // Inisialisasi dasar
    init_scr();
    dmaKit_init(D_CTRL_RELE_OFF, D_CTRL_MFD_OFF, D_CTRL_STS_UNSPEC,
                D_CTRL_STD_OFF, D_CTRL_RCYC_8QWC, D_CTRL_TTE_ON, D_CTRL_ENT_OFF,
                D_CTRL_ESTR_ON, D_CTRL_DIR_CHAIN, 0, 0);
    gsKit_init_global();

    GSGLOBAL *gsGlobal = gsKit_init_global();
    gsGlobal->PrimAlphaEnable = GS_SETTING_ON;

    gsKit_init_screen(gsGlobal);
    gsKit_clear(gsGlobal, GS_BLACK);

    // Load Texture
    GSTEXTURE narutoTex, gokuTex;
    gsKit_texture_bmp(gsGlobal, &narutoTex, "host:assets/naruto.bmp");
    gsKit_texture_bmp(gsGlobal, &gokuTex, "host:assets/goku.bmp");

    // Inisialisasi posisi karakter
    int narutoX = 100, narutoY = 200;
    int gokuX = 400, gokuY = 200;

    // Inisialisasi Controller
    padInit(0);

    while (1)
    {
        padRead(0);
        struct padButtonStatus buttons;
        buttons = padRead(0);

        u32 btn = 0xffff ^ buttons.btns;

        // Gerakkan Naruto
        if (btn & PAD_LEFT)
            narutoX -= SPEED;
        if (btn & PAD_RIGHT)
            narutoX += SPEED;
        if (btn & PAD_UP)
            narutoY -= SPEED;
        if (btn & PAD_DOWN)
            narutoY += SPEED;

        // Gerakkan Goku
        if (btn & PAD_TRIANGLE)
            gokuY -= SPEED;
        if (btn & PAD_CROSS)
            gokuY += SPEED;
        if (btn & PAD_L1)
            gokuX -= SPEED;
        if (btn & PAD_R1)
            gokuX += SPEED;

        // Gambar ke layar
        gsKit_clear(gsGlobal, GS_BLACK);
        gsKit_prim_sprite_texture(gsGlobal, &narutoTex,
                                  narutoX, narutoY,
                                  0.0f, 0.0f,
                                  narutoX + narutoTex.Width, narutoY + narutoTex.Height,
                                  narutoTex.Width, narutoTex.Height, 0x80808080);

        gsKit_prim_sprite_texture(gsGlobal, &gokuTex,
                                  gokuX, gokuY,
                                  0.0f, 0.0f,
                                  gokuX + gokuTex.Width, gokuY + gokuTex.Height,
                                  gokuTex.Width, gokuTex.Height, 0x80FFFFFF);

        gsKit_sync_flip(gsGlobal);
        gsKit_flip_screen(gsGlobal);
    }

    return 0;
}